export default {
    plugins: {
        "postcss-nesting": {},
        autoprefixer: {},
    },
};
