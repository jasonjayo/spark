
<img src="<?php echo e(asset('./images/logos/spark_no_subtitle.png')); ?>" <?php echo e($attributes); ?>>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/components/application-logo.blade.php ENDPATH**/ ?>