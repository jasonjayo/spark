<?php use \App\Models\Report; ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Bans - Admin Dashborad <?php $__env->endSlot(); ?>

    <div class="modal fade" id="banModal" tabindex="-1" aria-labelledby="banModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="banModalLabel">Ban User</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="ban-form" action="<?php echo e(route('ban.create')); ?>" method="POST" x-data="{ permBan: false }">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="ban_user_id" class="form-label">User ID</label>
                            <input required type="number" class="form-control" id="ban_user_id" name="user_id">
                        </div>
                        <div class="mb-3">
                            <label for="ban_reason" class="form-label">Reason</label>
                            <input required type="text" class="form-control" autocomplete="off" id="ban_reason"
                                name="reason">
                        </div>
                        <div class="mb-3">
                            <label for="ban_report_id" class="form-label">Linked report (optional)</label>
                            <input required type="text" class="form-control" id="ban_report_id" name="report_id">
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" x-model="permBan"
                                id="ban_perm">
                            <label class="form-check-label" for="ban_perm">
                                Permanent ban
                            </label>
                        </div>
                        <div class="mb-3" x-show="!permBan">
                            <label for="ban_expiry" class="form-label">Expiry</label>
                            <input type="date" class="form-control" id="ban_expiry" name="expiry">
                        </div>
                        <button type="submit" class="btn btn-primary">Ban</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <div class="row">
            <h2 class="col-12">
                Reports
            </h2>
        </div>
        <div class="row">
            <div class="col">
                <table class="table table-striped" x-data="">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Reporter</th>
                            <th scope="col">Reported</th>
                            <th scope="col">Reason</th>
                            <th scope="col">Status</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        <?php
                            $reports = Report::orderBy('id', 'desc')->paginate(10);
                        ?>
                        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($report->id); ?></th>

                                <td>
                                    <?php if($report->reporter): ?>
                                        <a class="link-underline link-underline-opacity-0 link-underline-opacity-75-hover"
                                            href="/viewprofile/<?php echo e($report->reporter_id); ?>">
                                    <?php endif; ?>
                                    <?php echo e($report->getReporterName()); ?>

                                    <?php if($report->reporter): ?>
                                        </a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a class="link-underline link-underline-opacity-0 link-underline-opacity-75-hover"
                                        href="/viewprofile/<?php echo e($report->reported_id); ?>">
                                        <?php echo e($report->getReportedName()); ?>

                                    </a>
                                </td>
                                <td><?php echo e($report->reason); ?></td>
                                <td><?php echo e($report->status); ?></td>
                                <td>
                                    <?php if($report->status != 'CLOSED'): ?>
                                        <button class="btn btn-primary me-1" data-bs-toggle="modal"
                                            data-bs-target="#banModal" data-reported-id="<?php echo e($report->reported_id); ?>"
                                            data-report-id="<?php echo e($report->id); ?>"
                                            x-on:click="prepBanModal">Ban</button>
                                        <form action="<?php echo e(route('report.close')); ?>" method="POST"
                                            class="d-inline-block">
                                            <?php echo csrf_field(); ?>
                                            <input type="text" hidden name="id" value="<?php echo e($report->id); ?>">
                                            <button class="btn btn-primary">Close</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($reports->links()); ?>

            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/admin-reports.blade.php ENDPATH**/ ?>