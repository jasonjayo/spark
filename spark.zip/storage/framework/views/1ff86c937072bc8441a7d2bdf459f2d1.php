<?php use \App\Models\User; ?>
<?php use \App\Models\Profile; ?>
<?php use \App\Models\Photo; ?>


<?php if (! $__env->hasRenderedOnce('d6d92e05-9cf7-4b42-a2ff-71feb657e2f9')): $__env->markAsRenderedOnce('d6d92e05-9cf7-4b42-a2ff-71feb657e2f9');
$__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/chat.js', 'resources/css/viewprofile.css']); ?>
<?php $__env->stopPush(); endif; ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <script>
        const other_user = {
            id: <?php echo e(request()->id); ?>,
            first_name: "<?php echo e($other_user->first_name); ?>"
        }
    </script>

     <?php $__env->slot('title', null, []); ?> Chat <?php $__env->endSlot(); ?>

    <main class="container-fluid chat-page">
        <div class="row">
            <div class="col-4 col-md-4 d-none mb-4 d-md-block pt-4">
                <h3 class="text-center mb-4">Your Sparks</h3>
                <?php if (isset($component)) { $__componentOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chat-user-list','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('chat-user-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44)): ?>
<?php $attributes = $__attributesOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44; ?>
<?php unset($__attributesOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44)): ?>
<?php $component = $__componentOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44; ?>
<?php unset($__componentOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44); ?>
<?php endif; ?>
            </div>
            <div id="inner" class="col-12 col-md-8">
                <!-- View Profile button with profile picture -->
                <div class="d-flex justify-content-between align-items-center border-bottom px-3 py-2">
                    <div class="d-flex align-items-center">
                        <a class="text-decoration-none text-black" href="<?php echo e(url('/viewprofile/' . $other_user->id)); ?>"
                            style="color: #de3163;">
                            <h4 class="fw-b"><?php echo e($other_user->first_name); ?></h4>
                        </a>
                    </div>
                    <div>
                        <button type="button" class="btn btn-lg btn-primary bg-transparent" data-bs-toggle="modal"
                            data-bs-target="#reportModal">
                            <span class="material-symbols-outlined text-danger" style="font-size: 40px;">flag</span>
                        </button>
                    </div>
                </div>
                <div class="modal fade" id="reportModal" tabindex="-1" aria-labelledby="reportModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="ban-modal-header modal-header">
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                                <div class="ban-modal-title-container modal-title-container">
                                    <h5 class="modal-title" id="reportModalLabel">Report</h5>
                                    <p class="ban-modal-subtitle modal-subtitle">Don't worry,
                                        <?php echo e($other_user->first_name); ?> won't find out.</p>
                                </div>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('report.create')); ?>" method="POST" id="reportForm">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="reported_id" value="<?php echo e($other_user->id); ?>">
                                    <div class="mb-3">
                                        <div class="d-grid gap-2">
                                            <button type="submit" class="btn btn-report" name="reason"
                                                value="Inappropriate Messages">Inappropriate Messages</button>
                                            <button type="submit" class="btn btn-report" name="reason"
                                                value="Inappropriate Photos">Inappropriate Photos</button>
                                            <button type="submit" class="btn btn-report" name="reason"
                                                value="Spam">Feels like Spam</button>
                                            <button type="button" class="btn btn-report" data-bs-toggle="collapse"
                                                data-bs-target="#otherReasonField">Other</button>
                                        </div>
                                    </div>
                                </form>
                                <div class="collapse" id="otherReasonField">
                                    <form action="<?php echo e(route('report.create')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="reported_id" value="<?php echo e($other_user->id); ?>">
                                        <div class="mb-3">
                                            <textarea class="form-control" id="otherReason" name="reason" rows="3" placeholder="Enter reason"></textarea>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary">Submit Report</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <ul id="messages" class="d-flex flex-column p-3 m-auto">
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isOwnMsg = $message->sender_id != Auth::user()->id;
                        ?>
                        <li class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'm-1 p-2 d-inline-block rounded-3 chat-message',
                            'bg-primary text-light align-self-end' => !$isOwnMsg,
                            'bg-secondary text-light align-self-start' => $isOwnMsg,
                        ]); ?>" title="<?php echo e($message->created); ?>"><?php echo e($message->content); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="row">
                    <div class="col-md-9 col-12" id="typing-alert" x-data>
                        <span class="text-secondary"><span x-text="other_user.first_name"></span> is typing</span>
                        <span class="typing-dot text-secondary rounded"></span>
                        <span class="typing-dot text-secondary rounded"></span>
                        <span class="typing-dot text-secondary rounded"></span>
                    </div>
                </div>
                <div class="row">
                    <form class="col-12 m-auto d-flex pt-2" id="send-msg-form" x-data="">
                        <?php echo csrf_field(); ?>
                        <label class="visually-hidden" for="message">Message</label>
                        <input autocomplete="off" type="text" class="form-control me-2" id="message"
                            placeholder="Message" name="content" @keydown.throttle.3000ms="whisperTyping">
                        <input hidden name="recipient_id" value="<?php echo e(request()->id); ?>">
                        <button type="submit" class="btn btn-primary">Send</button>
                    </form>
                </div>
                <div class="row">
                    <div class="col-12 pt-1 text-secondary" id="chat-connection-status">
                        Connecting to chat...
                    </div>
                </div>
            </div>
        </div>

        <div id="toasts"></div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/chat.blade.php ENDPATH**/ ?>