<?php use \App\Enums\Gender; ?>
<?php use \App\Models\Interest; ?>

<?php if (! $__env->hasRenderedOnce('9d5ebcf4-29a5-4cf3-8609-163f45fd7edc')): $__env->markAsRenderedOnce('9d5ebcf4-29a5-4cf3-8609-163f45fd7edc');
$__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/search.js', 'resources/css/search.css']); ?>
<?php $__env->stopPush(); endif; ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Search <?php $__env->endSlot(); ?>


    <div class="fluid-container search m-0">
        <div class=" row">
            <form class="col-12 sideform col-md-5 col-lg-3 d-flex flex-column" action="" method="GET"
                id="filters_form">

                <div class="sticky-top">
                    <div class="form-floating my-3 mx-4">
                        <input type="text" class="form-control" id="filter_query" name="query"
                            placeholder="Search name, tagline" autocomplete="off" value="<?php echo e(old('query')); ?>">
                        <label for="filter_query">Search name, tagline</label>
                    </div>
                    <div class="form-label-group my-3 mx-4" x-data="{ min_age: <?php echo e(old('min_age', 18)); ?> }">
                        <label for="filter_min_age" class="form-label">Min age</label>
                        <span id="min_age_val" x-text="min_age"></span>
                        <input type="range" class="form-range" min="18" max="100" id="filter_min_age"
                            name="min_age" x-model="min_age">
                    </div>
                    <div class="form-label-group my-3 mx-4" x-data="{ max_age: <?php echo e(old('max_age', 100)); ?> }">
                        <label for="filter_max_age" class="form-label">Max age</label>
                        <span id="max_age_val" x-text="max_age"></span><span x-show="max_age >= 100">+</span>
                        <input type="range" class="form-range" min="18" max="100" id="filter_max_age"
                            name="max_age" x-model="max_age">
                    </div>
                    <?php if(!Auth::user()->isAdmin()): ?>
                        <div class="form-label-group my-3 mx-4" x-data="{ max_distance: <?php echo e(old('max_distance', 100)); ?> }">
                            <label for="filter_max_distance" class="form-label">Max distance</label>
                            <span id="max_distance_val" x-text="max_distance"></span><span
                                x-show="max_distance >= 100">+</span> km
                            <input type="range" class="form-range" min="1" max="100"
                                id="filter_max_distance" name="max_distance" x-model="max_distance">
                        </div>
                    <?php endif; ?>
                    <div class="form-label-group my-3 mx-4">
                        <label for="filter_gender" class="form-label">Gender</label>
                        <select class="form-select" name="gender" id="filter_gender">
                            <option value="all">All</option>
                            <?php $__currentLoopData = Gender::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($gender->value); ?>"
                                    <?php echo e($gender->value == old('gender') ? 'selected' : ''); ?>>
                                    <?php echo e($gender->getLabel()); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-label-group my-3 mx-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="yes"
                                <?php echo e(old('online_now') == 'yes' ? 'checked' : ''); ?> id="filter_online_now"
                                name="online_now">
                            <label class="form-check-label" for="filter_online_now">
                                Online now
                            </label>
                        </div>
                    </div>
                    <div class="form-label-group my-3 mx-4">
                        <div class="dropdown">
                            <button class="btn btn-outline-primary dropdown-toggle" type="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                Interests
                            </button>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = DB::table('interests')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="#" class="dropdown-item interest_option"
                                            data-interest-id="<?php echo e($interest->id); ?>"><?php echo e($interest->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between my-3 mx-4">
                        <a class="btn btn-outline-secondary" href="./search">Reset</a>
                        <button class="btn btn-primary">Search</button>

                    </div>
                    <div class="col-12 mx-4">
                        <?php $__currentLoopData = array_filter(explode(',', old('interests'))); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="interest-pill badge rounded-pill p-2 text-bg-secondary"
                                data-interest-id="<?php echo e($interest_id); ?>">
                                <?php echo e(Interest::find($interest_id)->name); ?>

                                <button type="button" class="btn-close ms-1" aria-label="Close"></button>
                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                    <input hidden type="text" id="filter_interests" name="interests" value=<?php echo e(old('interests')); ?>>
                </div>
            </form>


            <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="toasts">
                    <div class="toast show align-items-center text-bg-primary bg-danger border-0" role="alert"
                        aria-live="assertive" aria-atomic="true">
                        <div class="d-flex">
                            <div class="toast-body">
                                <?php echo e($error); ?>

                            </div>
                            <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast"
                                aria-label="Close"></button>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="col-12 col-md-7 col-lg-9">
                <div id="searchResults" class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 m-4 g-4">
                    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <?php if (isset($component)) { $__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2 = $attributes; } ?>
<?php $component = App\View\Components\ProfileCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('profile-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ProfileCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['profile' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($profile)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2)): ?>
<?php $attributes = $__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2; ?>
<?php unset($__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2)): ?>
<?php $component = $__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2; ?>
<?php unset($__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2); ?>
<?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-12 col-sm-6 pagination-links">
                        <?php echo e($profiles->links()); ?>

                    </div>
                </div>
            </div>


            <div class="col-12">
                <div class="row">
                </div>
            </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/search.blade.php ENDPATH**/ ?>