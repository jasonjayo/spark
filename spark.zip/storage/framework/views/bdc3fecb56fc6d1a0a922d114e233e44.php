<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['profile']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['profile']); ?>
<?php foreach (array_filter((['profile']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php use \App\Models\Photo; ?>
<?php use \App\Models\Profile; ?>

<?php if (! $__env->hasRenderedOnce('24648a0d-76d3-4c01-844a-e54463de2f76')): $__env->markAsRenderedOnce('24648a0d-76d3-4c01-844a-e54463de2f76');
$__env->startPush('styles'); ?>
    <style>
        .card:hover {
            border-color: var(--spk-color-primary-1);
            transition: 0.1s linear;
        }

        .card {
            text-decoration: none;
            border-width: 2px;
            border-radius: 3px;
            border-color: transparent;
        }
    </style>
<?php $__env->stopPush(); endif; ?>
<?php
$photoUrls = [];
?>

<?php $__currentLoopData = Photo::where('user_id', $profile->user_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php array_push($photoUrls, $photo->photo_url); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php
if (Arr::get($photoUrls, 0) == null) {
    $coverPhoto = 'https://placehold.co/300x300?text=Photo';
} else {
    $coverPhoto = asset('images/profilePhotos/' . $photoUrls[0]);
}
?>





<a href="<?php echo e(route('viewprofile', ['id' => $profile->user->id])); ?>" class="card h-100 profile-card">
    <img src="<?php echo e($coverPhoto); ?>" class="card-img-top" alt="Photo of <?php echo e($profile->user->first_name); ?>" height="247.3px"
        width="247.3px" style="object-fit: cover">
    <div class="card-body">
        <h4 class="card-title d-flex justify-content-between">
            <div class="d-flex align-items-center"><?php echo e($profile->user->first_name); ?>

                <?php if($profile->isActive()): ?>
                    <span title="Active now" class="online-now ms-3 text-bg-success rounded-circle"></span>
                <?php else: ?>
                    <span title="Offline" class="offline ms-3 text-bg-secondary rounded-circle"></span>
                <?php endif; ?>
            </div>
            <div><?php echo e($profile->getAge()); ?></div>
        </h4>
        <?php if(!$profile->isActive()): ?>
            Last seen <?php echo e($profile->getLastActive()); ?>

        <?php endif; ?>
        <p class="card-text">
            <?php echo e($profile->tagline); ?>

        <ul>
            <li><?php echo e($profile->gender->getLabel()); ?></li>
            <li>Interested in: <?php echo e($profile->interested_in->getLabel()); ?></li>
            <li>Looking for: <?php echo e($profile->seeking->getLabel()); ?></li>
            <?php if(isset($profile->university)): ?>
                <li><?php echo e($profile->university); ?></li>
            <?php endif; ?>
            <?php if($profile->getDistance() != null): ?>
                <li><?php echo e($profile->getDistance()); ?></li>
            <?php endif; ?>
        </ul>
        </p>
    </div>
</a>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/components/profile-card.blade.php ENDPATH**/ ?>