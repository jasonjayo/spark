<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('title', null, []); ?> Discovery Queue <?php $__env->endSlot(); ?>

    <div class="text-center p-4">
        <h2><b>✨ Your Personalised Discovery Queue</b></h2>
        <p class="m-0">View profiles selected just for you.</p>
    </div>
    <div class="container">

        <?php
            $recommendation = $recommendations->first();
        ?>
        <?php if($recommendation !== null): ?>
            <div class="row">
                <div class="col-md-4"></div>

                <div class=" col-12 col-md-4">
                    <?php if (isset($component)) { $__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2 = $attributes; } ?>
<?php $component = App\View\Components\ProfileCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('profile-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ProfileCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['profile' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($recommendation->profile)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2)): ?>
<?php $attributes = $__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2; ?>
<?php unset($__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2)): ?>
<?php $component = $__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2; ?>
<?php unset($__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2); ?>
<?php endif; ?>
                </div>
                <div class="colmd--4"></div>

            </div>

            <div class="row">
                <div class="col-12">
                    <div class="d-flex justify-content-center mt-3 mb-3">
                        <form action="react" method="POST" class="p-3">
                            <?php echo csrf_field(); ?>
                            <input hidden type="text" name="id" value="<?php echo e($recommendation->id); ?>">
                            <input hidden type="text" name="type" value="LIKE">
                            <button type="submit" class="btn btn-primary fs-4 text-uppercase"><i
                                    class="bi bi-check"></i><b>Like</b></button>
                        </form>
                        <form action="react" method="POST" class="p-3">
                            <?php echo csrf_field(); ?>
                            <input hidden type="text" name="id" value="<?php echo e($recommendation->id); ?>">
                            <input hidden type="text" name="type" value="DISLIKE">
                            <button type="submit" class="btn btn-primary fs-4 text-uppercase"><i
                                    class="bi bi-x"></i><b>Dislike</b></button>
                        </form>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-12 text-center mt-5">
                    <div class="mb-3">
                        <i class="bi bi-check-square-fill" id="discovery-empty-icon"></i>
                    </div>
                    <b class="fs-5">You've completed your discovery queue for now.<br>
                        Come back later!</b>
                </div>
            </div>
        <?php endif; ?>

    </div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/discovery.blade.php ENDPATH**/ ?>