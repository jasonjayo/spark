<?php use \App\Models\Report; ?>
<?php use \App\Models\Ban; ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Admin Dashborad <?php $__env->endSlot(); ?>

    <div class="modal fade" id="banModal" tabindex="-1" aria-labelledby="banModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="banModalLabel">Ban User</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="ban-form" action="<?php echo e(route('ban.create')); ?>" method="POST" x-data="{ permBan: false }">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="ban_user_id" class="form-label">User ID</label>
                            <input required type="number" class="form-control" id="ban_user_id" name="user_id">
                        </div>
                        <div class="mb-3">
                            <label for="ban_reason" class="form-label">Reason</label>
                            <input required type="text" class="form-control" autocomplete="off" id="ban_reason"
                                name="reason">
                        </div>
                        <div class="mb-3">
                            <label for="ban_report_id" class="form-label">Linked report (optional)</label>
                            <input required type="text" class="form-control" id="ban_report_id" name="report_id">
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" value="" x-model="permBan"
                                id="ban_perm">
                            <label class="form-check-label" for="ban_perm">
                                Permanent ban
                            </label>
                        </div>
                        <div class="mb-3" x-show="!permBan">
                            <label for="ban_expiry" class="form-label">Expiry</label>
                            <input type="date" class="form-control" id="ban_expiry" name="expiry">
                        </div>
                        <button type="submit" class="btn btn-primary">Ban</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">

        <?php if(session('report_closed')): ?>
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-success" role="alert">
                        Report successfully closed
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if(session('ban_id')): ?>
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-success" role="alert">
                        Ban created successfully (Ban ID: <?php echo e(session('ban_id')); ?>)
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if(session('ban_revoked')): ?>
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-success" role="alert">
                        Ban successfully revoked
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if(session('account_deleted')): ?>
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-success" role="alert">
                        Account successfully deleted
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-12">
                <h1>Admin Dashboard</h1>
            </div>
        </div>

        <div class="row">
            <div class="col-3">
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-primary">Logout</button>
                </form>
            </div>
        </div>

        <?php echo e($slot); ?>


        


    </div>

    <script>
        function prepBanModal(e) {
            document.querySelector("#ban_user_id").value = e.target.getAttribute("data-reported-id");
            document.querySelector("#ban_report_id").value = e.target.getAttribute("data-report-id");
        }
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/components/admin.blade.php ENDPATH**/ ?>