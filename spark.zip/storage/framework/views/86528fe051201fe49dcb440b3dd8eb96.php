<?php use \App\Models\Ban; ?>

<div class="row">
    <h2 class="col-12">
        Bans
    </h2>
</div>

<div class="row">
    <div class="col">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">User</th>
                    <th scope="col">Admin</th>
                    <th scope="col">Reason</th>
                    <th scope="col">Report ID</th>
                    <th scope="col">Active From</th>
                    <th scope="col">Active To</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                <?php
                    $bans = Ban::paginate(10);
                ?>
                <?php $__currentLoopData = $bans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($ban->id); ?></th>
                        <td><a class="link-underline link-underline-opacity-0 link-underline-opacity-75-hover"
                                href="viewprofile/<?php echo e($ban->user_id); ?>"><?php echo e($ban->user->first_name . ' ' . $ban->user->second_name); ?>

                            </a></td>
                        <td><?php echo e($ban->admin->first_name); ?></td>
                        <td><?php echo e($ban->reason); ?></td>
                        <td><?php echo e($ban->report_id); ?></td>
                        <td><?php echo e($ban->active_from); ?></td>
                        <td><?php echo e($ban->active_to ?? 'Permanent'); ?></td>
                        <td>
                            <form action="<?php echo e(route('ban.revoke')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input hidden type="text" name="id" value="<?php echo e($ban->id); ?>">
                                <button class="btn btn-primary">Revoke</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($bans->links()); ?>


    </div>
</div>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/components/admin-bans.blade.php ENDPATH**/ ?>