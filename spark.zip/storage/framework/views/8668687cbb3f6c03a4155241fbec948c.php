<?php use \App\Models\Photo; ?>

<section>
    <style>
        .imgContainer {
            position: relative;
        }

        .img {
            opacity: 1;
            display: block;
            width: 100%;
            transition: .5s ease;
            backface-visibility: hidden;
            object-fit: cover;
            width: 230px;
            height: 200px;
            border-radius: 10%;
            border: 3px solid #b61a47;
            overflow: auto;

        }

        .buttonContainer {
            transition: .5s ease;
            opacity: 0;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            text-align: center;
        }

        .imgContainer:hover .img {
            opacity: 0.3;
        }

        .imgContainer:hover .buttonContainer {
            opacity: 1;
        }
    </style>
    <header>
        <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
            <?php echo e(__('Update Photos')); ?>

        </h2>

        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
            <?php echo e(__('Update your profile photos here.')); ?>

        </p>
    </header>
    <?php if(session('status') === 'photo-saved'): ?>
        <div class="alert alert-success" role="alert">
            Photo saved!
        </div>
    <?php elseif(session('status') === 'photo-deleted'): ?>
        <div class="alert alert-success" role="alert">
            Photo deleted!
        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo e(route('photo.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <input type="text" name="id" value="<?php echo e($user->id); ?>" hidden>

        <div class="mb-3">
            <label for="image" class="form-label">
                <h4>Add Photo</h4>
            </label>
            <input class="form-control" type="file" name="image" id="image">
        </div>

        <div class="form-floating mb-3">
            <input class="form-control mb-3" type="text" name="photoName" id="photoName"
                placeholder="Selfie with my Dog">
            <label for="photoName">Photo Name </label>
        </div>

        <button type="submit" name="photo" class="btn btn-primary">Upload Photo</button>
    </form>


    <br>

    <div class="mb-3 mt-4">
        <h4>Current Photo Selection</h4>
    </div>
    <div class="container">
        <div class="row ">

            <form method="post" action="<?php echo e(route('photo.destroy')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>

                <?php $__currentLoopData = Photo::where('user_id', $user->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="imgContainer d-flex justify-content-center col-3 my-1">
                        <img src="<?php echo e(asset('images/profilePhotos/' . $photo->photo_url)); ?>" class="img" />
                        <div class="buttonContainer">
                            <input type="hidden" id="photoId" name="photoId" value= "<?php echo e($photo->id); ?>" />
                            <input type="hidden" id="photoUrl" name="photoUrl" value= "<?php echo e($photo->photo_url); ?>" />
                            <button type="submit" name="photoDelete" class="delBtn btn btn-primary">Delete
                                Photo</button>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </form>
        </div>
    </div>

</section>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/profile/partials/profile-photos.blade.php ENDPATH**/ ?>