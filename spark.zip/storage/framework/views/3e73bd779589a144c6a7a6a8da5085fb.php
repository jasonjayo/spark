<?php use \App\Enums\Gender; ?>
<?php use \App\Enums\InterestedIn; ?>
<?php use \App\Enums\Seeking; ?>
<?php use \App\Models\User; ?>
<?php use \App\Models\Interest; ?>
<?php use \App\Models\SparkTrait; ?>

<?php if (! $__env->hasRenderedOnce('bf554a52-cb2f-4e60-bdcf-cc79f12db3d0')): $__env->markAsRenderedOnce('bf554a52-cb2f-4e60-bdcf-cc79f12db3d0');
$__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/updateProfile.js']); ?>
<?php $__env->stopPush(); endif; ?>

<section>
    <style>
        /* styles for traits & interests pill buttons */
        .ba {
            border-style: solid;
            border-width: 1px;
        }

        .br-pill {
            border-radius: 9999px;
        }

        .bw1 {
            border-width: .125rem;
        }

        .bw2 {
            border-width: .25rem;
        }

        .dib {
            display: inline-block;
        }

        .fw6 {
            font-weight: 600;
        }

        .tracked {
            letter-spacing: .1em;
        }

        .link {
            text-decoration: none;
            transition: color .15s ease-in;
        }

        .pv2 {
            padding-top: .5rem;
            padding-bottom: .5rem;
        }

        .ph3 {
            padding-left: 1rem;
            padding-right: 1rem;
        }

        .mb2 {
            margin-bottom: .5rem;
        }

        .mb4 {
            margin-bottom: 2rem;
        }

        .mt4 {
            margin-top: 2rem;
        }


        .f6 {
            font-size: .875rem;
        }

        .dim {
            opacity: 1;
            transition: opacity .15s ease-in;
        }

        .dim:hover,
        .dim:focus {
            opacity: .5;
            transition: opacity .15s ease-in;
        }

        .intr_color {
            border-color: var(--spk-color-primary-1);
            color: var(--spk-color-primary-1);
        }

        .traits_color {
            border-color: var(--spk-color-secondary-1);
            color: var(--spk-color-secondary-1);
        }

        .on {

            background-color: var(--spk-color-primary-1);
            color: white;
        }

        .onTwo {
            background-color: var(--spk-color-secondary-1);
            color: white;
        }
    </style>


    <?php
    $firstToUpper = ucfirst($user->first_name);
    $secondToUpper = ucfirst($user->second_name);
    
    $hasProfile = isset($user->profile);
    if ($hasProfile) {
        $profile = $user->profile;
    }
    
    $hasPhotos = DB::table('photos')->where('user_id', '=', auth()->id())->get();
    $userinterests = DB::table('interest_user')->where('user_id', '=', auth()->id())->get();
    $usertraits = DB::table('trait_user')->where('user_id', '=', auth()->id())->get();
    $hasInterests = false;
    $hasTraits = false;
    ?>
    <script>
        var selectedInterests = [];
        var selectedTraits = [];
    </script>


    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Interests and Traits</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="interestsTraitsUpdateAlert" style="display:none;" class="alert alert-success"
                        role="alert">
                        Your interests and traits were updated successfully!
                    </div>
                    <h5 class="modal-title" id="exampleModalLabel">Let's Get Personal!✨</h5>
                    <div class="ph3 mt4">
                        <h1 class="f6 fw6 ttu tracked">Elevate your profile! Choose the interests that make you stand
                            out!</h1>
                        <?php
                            $my_interests = $user->interests->pluck('id');
                        ?>
                        <?php $__currentLoopData = Interest::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button id="<?php echo e($interest->id); ?>" class="f6 link dim br-pill ba ph3 pv2 mb2 dib intr_color"
                                href="#0" data-interest-name="<?php echo e($interest->name); ?>"
                                data-interest-id="<?php echo e($interest->id); ?>" data-interest-category="testCat"
                                onclick="addSelectedInterest(this)">
                                <?php echo e($interest->name); ?>

                                <span><?php echo e($interest->emoji); ?></span>
                            </button>
                            <?php if($my_interests->contains($interest->id)): ?>
                                <script>
                                    var intButton = document.getElementById("<?php echo e($interest->id); ?>");
                                    selectedInterests.push("<?php echo e($interest->id); ?>");
                                    intButton.classList.add('on');
                                </script>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="ph3 mt4">
                        <h1 class="f6 fw6 ttu tracked">Ready to reveal your vibe? Select your personality traits!</h1>
                        <?php
                            $my_traits = $user->traits->pluck('id');
                        ?>
                        <?php $__currentLoopData = SparkTrait::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button id="<?php echo e($trait->id); ?>_trait"
                                class="f6 link dim br-pill ba ph3 pv2 mb2 dib  traits_color" href="#0"
                                data-trait-name="<?php echo e($trait->name); ?>" data-trait-id="<?php echo e($trait->id); ?>"
                                data-trait-category="testCat" onclick="addSelectedTrait(this)">
                                <?php echo e($trait->name); ?>

                                <span><?php echo e($trait->emoji); ?></span>
                            </button>
                            <?php if($my_traits->contains($trait->id)): ?>
                                <script>
                                    var traitButton = document.getElementById("<?php echo e($trait->id); ?>_trait");
                                    selectedTraits.push("<?php echo e($trait->id); ?>");
                                    traitButton.classList.add('onTwo');
                                </script>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <form id="interestsTraitsForm">
                        <input type="hidden" id="user_id" value="<?php echo e($user->id); ?>">
                        <input type="hidden" class="interestInput" value="" name="interests" id="interests" />
                        <input type="hidden" class="traitInput" value="" name="traits" id="traits" />

                        <button type="submit" class="btn btn-primary" data-dismiss="modal">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <header>
        <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
            <?php echo e(__($firstToUpper . "'s " . 'Profile Information')); ?>

        </h2>

        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
            <?php echo e(__("Update your account's profile information.")); ?>

        </p>
        <div>

        </div>
    </header>

    <form id="send-verification" method="post" action="<?php echo e(route('verification.send')); ?>">
        <?php echo csrf_field(); ?>
    </form>

    <!-- Modal -->
    <?php if(session('status') === 'interestsAndTraits-created'): ?>
        <div class="alert alert-success" role="alert">
            Your chosen interests and traits have been saved!!
        </div>
    <?php endif; ?>

    <?php if(session('status') === 'profile-updated'): ?>
        <?php if($hasPhotos->isEmpty() && !Auth::user()->isAdmin()): ?>
            <div class="alert alert-success" role="alert">
                Profile saved! Why not upload some pictures to your profile in the <a
                    href="/profile?section=section4">Update Photos</a> section!
            </div>
        <?php else: ?>
            <div class="alert alert-success" role="alert">
                Profile saved!
            </div>
        <?php endif; ?>

    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo e(route('profile.store')); ?>" class="mt-6 space-y-6">
        <?php echo csrf_field(); ?>

        <?php if(!$hasProfile && !Auth::user()->isAdmin()): ?>
            <div class="alert alert-primary" role="alert">
                <b>You haven't created your profile yet. Fill out your details below to get full access to Spark.</b>
            </div>
        <?php endif; ?>




        <form method="post" action="<?php echo e(route('profile.store')); ?>" class="mt-6 space-y-6">
            <?php echo csrf_field(); ?>

            <div class="container d-flex flex-column ">

                <!-- Basic Details Div -->
                <div class="mb-3">
                    <h2>Basic Details</h2>
                    <p>These details cannot be changed.</p>

                    <div class="form-floating mb-3"> <!-- User Id  -->
                        <input id="profile_user_id" name="id" type="text" class="form-control mt-1 block w-full"
                            value="<?php echo e(old('id', $user->id)); ?>" required autofocus readonly />
                        <label for="profile_user_id">User ID </label>


                    </div>

                    <div class="form-floating mb-3"> <!-- First Name Input -->

                        <input id="first_name" autocomplete="name" name="first_name" type="text"
                            class="form-control mt-1 block {$gray-500}-bg-subtle"
                            value="<?php echo e(old('first_name', $firstToUpper)); ?>" required readonly />
                        <label for="first_name">First Name</label>
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('first_name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('first_name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>

                    <div class="form-floating mb-3"> <!-- Second Name Input -->
                        <input id="second_name" name="second_name" type="text"
                            class="form-control mt-1 block w-full" value="<?php echo e(old('second_name', $secondToUpper)); ?>"
                            required readonly />
                        <label for="second_name">Second Name </label>
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>

                    <div class="form-floating mb-3"> <!-- DOB -->
                        <input id="dob" name="dob" type="date" class="form-control mt-1 block w-full"
                            value="<?php echo e($user->dob); ?>" required readonly />
                        <label for="second_name">Date of Birth </label>
                    </div>
                </div>



                <!--Personal Details -->
                <div class="mb-3">
                    <h2>A Bit More About Yourself</h2>
                    <div class="form-floating mb-3">
                        <!-- Gender Input -->
                        <select name="gender" class="form-select mb-2" id="gender">
                            <?php $__currentLoopData = Gender::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($gender->value); ?>"
                                    <?php echo e($gender->value == old('gender', $hasProfile ? $profile->gender->value : 'o') ? 'selected' : ''); ?>>
                                    <?php echo e($gender->getLabel()); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="gender">How do you identify?</label>
                    </div>
                    <div class="form-floating mb-3">
                        <!-- Bio -->
                        <textarea class="form-control" id="bio" name="bio" style="height:100px" cols="50" maxlength="1000"
                            placeholder="Describe yourself here..."><?php echo e(old('bio', $hasProfile ? $profile->bio : '')); ?></textarea>
                        <label for="bio">Write a bio about yourself here...</label>
                    </div>

                    <div class="form-floating mb-3">
                        <!-- Tagline -->
                        <input id="tagline" name="tagline" type="text" class="form-control" size="50"
                            placeholder="I am a coffee lover!" maxlength="50"
                            value="<?php echo e(old('tagline', $hasProfile ? $profile->tagline : '')); ?>" />
                        <label for="tagline">First thing you'd say when you meet someone new?</label>

                    </div>

                    <div class="form-floating mb-3">
                        <!-- Interested In -->
                        <select name="interested_in" class="form-select mb-2" id="interested_in">
                            <?php $__currentLoopData = InterestedIn::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interested_in_option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($interested_in_option->name); ?>"
                                    <?php echo e($interested_in_option->name == old('interested_in', $hasProfile ? $profile->interested_in->name : 'ALL') ? 'selected' : ''); ?>>
                                    <?php echo e($interested_in_option->getLabel()); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="interested_in">What genders are you open to connecting with?</label>
                    </div>

                    <div class="form-floating mb-3">
                        <!-- Seeking -->
                        <select name="seeking" class="form-select" id="seeking">
                            <?php $__currentLoopData = Seeking::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seeking_option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($seeking_option->name); ?>"
                                    <?php echo e($seeking_option->name == old('seeking', $hasProfile ? $profile->seeking->name : 'UNKNOWN') ? 'selected' : ''); ?>>
                                    <?php echo e($seeking_option->getLabel()); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="seeking">Looking for long-term love or something shorter?</label>
                    </div>

                    <div class="form-floating mb-3">
                        <!-- University -->
                        <input name="university" type="text" class="form-control" id="floatingInput"
                            placeholder="University of Limerick" size="50" maxlength="50"
                            value="<?php echo e(old('university', $hasProfile ? $profile->university : '')); ?>">
                        <label for="floatingInput">Where do you study?</label>

                    </div>

                    <div class="form-floating mb-3">
                        <!-- Work -->
                        <input id="work" name="work" type="text" class="form-control" size="50"
                            placeholder="Barista" maxlength="50"
                            value="<?php echo e(old('work', $hasProfile ? $profile->work : '')); ?>" />
                        <label for="work">What do you work as?</label>

                    </div>
                    <!-- make the input box for this smaller so i can put the button beside it  -->
                    <p>Location will be set automatically by your browser, if you've <a target="_blank"
                            href="https://docs.buddypunch.com/en/articles/919258-how-to-enable-location-services-for-chrome-safari-edge-and-android-ios-devices-gps-setting">given
                            permission</a>.</p>

                </div>
                <div class="mb-3">
                    <h2>Interests and Traits</h2>
                    <p>By selecting some of the interests and traits that describe you best, we can find the best match
                        for you!</p>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#exampleModal">
                        Interests and Traits
                    </button>
                </div>


                <div>
                    <h2>Extra Bits</h2>
                    <p>These fields are optional.</p>
                    <div class="form-floating mb-3">
                        <!-- Favoutite Movie -->
                        <input id="fav_movie" name="fav_movie" type="text" class="form-control" maxlength=50
                            value="<?php echo e(old('fav_movie', $hasProfile ? $profile->fav_movie : '')); ?>"
                            placeholder="seven" />
                        <label for="fav_movie">Your top choice for a movie to watch?</label>
                    </div>

                    <div class="form-floating mb-3">
                        <!-- Favoutite Food -->
                        <input id="fav_food" name="fav_food" type="text" class="form-control" size=50
                            placeholder="Pizza" maxlength=50
                            value="<?php echo e(old('fav_food', $hasProfile ? $profile->fav_food : '')); ?>">
                        <label for="fav_food">One dish that you could eat for the rest of your life?</label>
                    </div>

                    <div class="form-floating mb-3">
                        <!-- Favoutite Song -->
                        <input id="fav_song" name="fav_song" type="text" class="form-control" size=50
                            placeholder="Everything She Wants" maxlength=50
                            value="<?php echo e(old('fav_song', $hasProfile ? $profile->fav_song : '')); ?>">
                        <label for="fav_song">What is your all-time favourite song?</label>
                    </div>

                    <div class="form-floating mb-3">
                        <!-- Personality Type -->
                        <input id="personality_type" name="personality_type" type="text" placeholder="ISFJ"
                            class="form-control" size=4 maxlength=4
                            value="<?php echo e(old('personality_type', $hasProfile ? $profile->personality_type : '')); ?>"
                            pattern="[A-Za-z]{4}" />
                        <label for="personality_type">What's your Myers Briggs Personality Type (e.g. INTP)</label>
                    </div>

                    <p style="padding-left:10px;color:#A9A9A9">Unsure? Click <a target="_blank"
                            href="https://www.16personalities.com/free-personality-test">here</a> to take a free
                        personality test and find out!</p>

                    <div class="form-floating mb-3">
                        <!-- Height -->
                        <input id="height" name="height" type="text" class="form-control" size=4
                            placeholder="1.75m" maxlength=4 pattern="^[0-9](\.[0-9]{0,2})?$"
                            value="<?php echo e(old('height', $hasProfile ? $profile->height : '')); ?>" />
                        <label for="height">How tall are you? (e.g. 1.53 Meters)</label>
                    </div>
                    <div class="form-floating mb-3">
                        <!-- Languages -->
                        <input id="languages" name="languages" type="text" class="form-control" size=50
                            placeholder="Gaeilge, English" maxlength=50
                            value="<?php echo e(old('languages', $hasProfile ? $profile->languages : '')); ?>" />
                        <label for="languages">Do you speak any lanuages?</label>
                    </div>
                </div>

                <div class="flex items-center gap-4 g">
                    <button class="btn btn-primary" name="profile">Save Profile</button>
                </div>
            </div>
        </form>
</section>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>