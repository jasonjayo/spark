<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('title', null, []); ?> Your Profile <?php $__env->endSlot(); ?>

    <div
        class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8  shadow p-2 mb-3 bg-white rounded d-flex justify-content-between">
        <div class="prof">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                Edit Profile
            </h2>
        </div>
        <div class="settings">
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" style="background:#de3163" type="button"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="bi bi-gear"></i>
                </button>
                <ul class="dropdown-menu">
                    <li><a href="?" class="dropdown-item">Edit Profile</a></li>
                    <?php if(!Auth::user()->isAdmin()): ?>
                        <li><a href="?section=section2" class="dropdown-item">Update Password</a></li>
                        <li><a href="?section=section3" class="dropdown-item">Delete Account</a></li>
                    <?php endif; ?>
                    <li><a href="?section=section4" class="dropdown-item">Update Photos</a></li>
                    <li>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <a href="route('logout')" class="dropdown-item"
                                onclick="event.preventDefault(); this.closest('form').submit();">
                                <?php echo e(__('Log Out')); ?>

                            </a>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <!-- Edit Profile -->
            <?php if(!isset($_GET['section'])): ?>
                <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                    <div class="max-w-m">
                        <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <!-- Update Password -->
            <?php elseif(isset($_GET['section']) && $_GET['section'] == 'section2'): ?>
                <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                    <div class="max-w-m">
                        <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>

                <!-- Delete Account -->
            <?php elseif(isset($_GET['section']) && $_GET['section'] == 'section3'): ?>
                <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                    <div class="max-w-m">
                        <?php echo $__env->make('profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>

                <!-- Photo Selection
            need array of photos, then foreach photo display a wee div and then make
        -->
            <?php elseif(isset($_GET['section']) && $_GET['section'] == 'section4'): ?>
                <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                    <div class="max-w-m">
                        <?php echo $__env->make('profile.partials.profile-photos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/profile/edit.blade.php ENDPATH**/ ?>