<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('title', null, []); ?> Chat <?php $__env->endSlot(); ?>

    <main class="container-fluid">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-4 mb-4 pt-4">
                <h3 class="text-center mb-4">Your Sparks</h3>
                <?php if (isset($component)) { $__componentOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chat-user-list','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('chat-user-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44)): ?>
<?php $attributes = $__attributesOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44; ?>
<?php unset($__attributesOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44)): ?>
<?php $component = $__componentOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44; ?>
<?php unset($__componentOriginal2b672b3c15b0c3de40c7cf0d0c4f8b44); ?>
<?php endif; ?>
            </div>
            <div class="col-8 p-5 d-none text-center d-md-flex justify-content-center align-items-center flex-column">
                <i class="bi-chat-dots chat-icon colored-text"></i>
                <h1 class="colored-text">Welcome to Spark Chat, <?php echo e(Auth::user()->first_name); ?>!</h1>
                <p class="colored-text">Click on a name to get started.</p>
            </div>
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<style>
    .chat-icon {
        font-size: 4.5em;

    }

    .colored-text {
        color: var(--spk-color-primary-2);
    }
</style>
<?php /**PATH C:\xampp\htdocs\spark\resources\views/chat-index.blade.php ENDPATH**/ ?>