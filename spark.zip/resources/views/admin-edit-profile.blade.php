<x-app-layout>

    <x-slot:title>Edit Profile</x-slot>
    @include('profile.partials.update-profile-information-form')

</x-app-layout>
